"""
CS 500 - Personal Budgeting Application
Author: [Your Name]
Date: June 2026

A command-line application that helps users manage personal finances
by tracking income, categorized expenses, and savings goals.
"""

import json
import matplotlib.pyplot as plt
from datetime import datetime


# ─────────────────────────────────────────────
# Budget Category Class
# ─────────────────────────────────────────────

class BudgetCategory:
    """Represents a single budget category (e.g., Housing, Food) with expenses."""

    def __init__(self, name):
        """Initialize a category with an empty expense list."""
        self.name = name
        self.expenses = []  # list of dicts: {amount, description, date}

    def add_expense(self, amount, description, date):
        """Add an expense entry to this category.

        Args:
            amount (float): Dollar amount of the expense (must be >= 0).
            description (str): Brief description of the expense.
            date (str): Date string in YYYY-MM-DD format.
        """
        expense = {
            "amount": amount,
            "description": description,
            "date": date
        }
        self.expenses.append(expense)

    def total_expenses(self):
        """Return the sum of all expenses in this category.

        Returns:
            float: Total amount spent in this category.
        """
        return sum(entry["amount"] for entry in self.expenses)


# ─────────────────────────────────────────────
# Budget Manager Class
# ─────────────────────────────────────────────

class BudgetManager:
    """Manages overall budget: income, savings goal, and all expense categories."""

    DATA_FILE = "budget_data.json"

    def __init__(self):
        """Initialize the manager and load any previously saved data."""
        self.income = 0.0
        self.savings_goal = 0.0
        self.categories = {}  # {category_name: BudgetCategory}
        self.load_data()

    def set_income(self, amount):
        """Set the monthly income.

        Args:
            amount (float): Monthly income in dollars.
        """
        self.income = amount

    def set_savings_goal(self, amount):
        """Set the target savings goal.

        Args:
            amount (float): Savings goal in dollars.
        """
        self.savings_goal = amount

    def add_expense(self, category_name, amount, description, date):
        """Add an expense to the named category, creating it if it does not exist.

        Args:
            category_name (str): Name of the expense category.
            amount (float): Dollar amount.
            description (str): Brief description.
            date (str): Date in YYYY-MM-DD format.
        """
        # Create category if it does not already exist
        if category_name not in self.categories:
            self.categories[category_name] = BudgetCategory(category_name)
        self.categories[category_name].add_expense(amount, description, date)

    def total_expenses(self):
        """Return the total expenses across all categories.

        Returns:
            float: Sum of all expenses.
        """
        return sum(cat.total_expenses() for cat in self.categories.values())

    def progress_toward_goal(self):
        """Calculate current savings (income minus total expenses).

        Returns:
            float: Current savings amount (can be negative if overspent).
        """
        return self.income - self.total_expenses()

    def save_data(self):
        """Persist income, savings goal, and all expenses to a JSON file."""
        data = {
            "income": self.income,
            "savings_goal": self.savings_goal,
            "categories": {}
        }
        for name, cat in self.categories.items():
            data["categories"][name] = cat.expenses

        try:
            with open(self.DATA_FILE, "w") as f:
                json.dump(data, f, indent=2)
        except OSError as e:
            print(f"Warning: Could not save data — {e}")

    def load_data(self):
        """Load previously saved budget data from a JSON file.

        Silently starts fresh if no file exists or the file is corrupt.
        """
        try:
            with open(self.DATA_FILE, "r") as f:
                data = json.load(f)

            self.income = float(data.get("income", 0.0))
            self.savings_goal = float(data.get("savings_goal", 0.0))

            for name, expenses in data.get("categories", {}).items():
                cat = BudgetCategory(name)
                cat.expenses = expenses
                self.categories[name] = cat

        except FileNotFoundError:
            pass  # First run — no saved data yet
        except (json.JSONDecodeError, KeyError, ValueError):
            print("Warning: Saved data appears corrupt. Starting fresh.")

    def visualize_expenses(self):
        """Display a pie chart breaking down spending by category using matplotlib."""
        labels = []
        amounts = []

        for name, cat in self.categories.items():
            total = cat.total_expenses()
            if total > 0:
                labels.append(name)
                amounts.append(total)

        if not amounts:
            print("No expense data available to visualize.")
            return

        plt.figure(figsize=(8, 6))
        plt.pie(amounts, labels=labels, autopct="%1.1f%%", startangle=90)
        plt.title("Expense Breakdown by Category")
        plt.tight_layout()
        plt.show()


# ─────────────────────────────────────────────
# Input Validation Functions
# ─────────────────────────────────────────────

def get_valid_float(prompt):
    """Prompt the user until a valid non-negative number is entered.

    Args:
        prompt (str): The message to display to the user.

    Returns:
        float: A validated non-negative floating-point number.
    """
    while True:
        user_input = input(prompt).strip()
        try:
            value = float(user_input)
            if value < 0:
                print("Value cannot be negative. Please try again.")
            else:
                return value
        except ValueError:
            print("Invalid input. Please enter a numeric value (e.g., 250.00).")


def get_valid_date(prompt):
    """Prompt the user until a valid date in YYYY-MM-DD format is entered.

    Args:
        prompt (str): The message to display to the user.

    Returns:
        str: A validated date string in YYYY-MM-DD format.
    """
    while True:
        date_str = input(prompt).strip()
        try:
            datetime.strptime(date_str, "%Y-%m-%d")
            return date_str
        except ValueError:
            print("Invalid date. Please use the format YYYY-MM-DD (e.g., 2026-06-01).")


# ─────────────────────────────────────────────
# Main Program
# ─────────────────────────────────────────────

def main():
    """Entry point: display the menu and handle user selections."""
    manager = BudgetManager()

    print("=" * 40)
    print("  Welcome to Personal Budgeting App!")
    print("=" * 40)

    while True:
        print("\nMenu:")
        print("1. Set Income")
        print("2. Set Savings Goal")
        print("3. Add Expense")
        print("4. View Total Expenses")
        print("5. View Savings Progress")
        print("6. Visualize Expenses")
        print("7. Save & Exit")

        choice = input("\nChoose an option (1-7): ").strip()

        # ── Option 1: Set Income ──────────────────
        if choice == "1":
            income = get_valid_float("Enter your monthly income: $")
            manager.set_income(income)
            print(f"Income set to: ${income:.2f}")

        # ── Option 2: Set Savings Goal ────────────
        elif choice == "2":
            goal = get_valid_float("Enter your savings goal: $")
            manager.set_savings_goal(goal)
            print(f"Savings goal set to: ${goal:.2f}")

        # ── Option 3: Add Expense ─────────────────
        elif choice == "3":
            category = input(
                "Enter expense category (e.g., Housing, Food, Transportation): "
            ).strip()
            if not category:
                print("Category cannot be empty. Please try again.")
                continue

            amount = get_valid_float("Enter expense amount: $")
            description = input("Enter a brief description: ").strip()
            date = get_valid_date("Enter expense date (YYYY-MM-DD): ")

            manager.add_expense(category, amount, description, date)
            print(f"Added ${amount:.2f} expense to '{category}' on {date}.")

        # ── Option 4: View Total Expenses ─────────
        elif choice == "4":
            total = manager.total_expenses()
            print(f"Total Expenses: ${total:.2f}")

        # ── Option 5: View Savings Progress ───────
        elif choice == "5":
            savings = manager.progress_toward_goal()
            if savings >= manager.savings_goal:
                print("You are on track!")
                print(f"Current savings: ${savings:.2f}")
            else:
                needed = manager.savings_goal - savings
                print(f"Current savings: ${savings:.2f}. "
                      f"You need ${needed:.2f} to reach your goal.")

        # ── Option 6: Visualize Expenses ──────────
        elif choice == "6":
            manager.visualize_expenses()

        # ── Option 7: Save & Exit ─────────────────
        elif choice == "7":
            manager.save_data()
            print("Data saved successfully. Exiting program. Goodbye!")
            break

        # ── Invalid Input ─────────────────────────
        else:
            print("Invalid choice. Please enter a number between 1 and 7.")


if __name__ == "__main__":
    main()
